//:[Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

let scena5 = Image(uiImage: UIImage(named: "scena5.png")!)
let storia = """
Trix is now in the future. The future is a deserted land and full of rubbish as result of the humans inability to preserve and care for the Earth's resources. Upon arriving here Trix is transformed in a robot cat. Now she can either help rebuild the future or be the final executioner...
"""

let colore_che_voglio = Color(red: 0.6196, green: 0.5843, blue: 0.0863)
let scena7 = Image(uiImage: UIImage(named: "scena7.png")!)
let storia_heaven = """
In the end Trix, because of all the good choices she made, during her journey, ends up in Heaven. Here is finally reunited with Dan and the live happily ever after together!!!
"""

let colore = Color(red: 0.3882, green: 0, blue : 0.4863)

let scena6 = Image(uiImage: UIImage(named: "scena6.png")!)
let storia_hell = """
In the end, because of the bad choices she made during her journey, Trix ends up in Hell, forever alone without her loveer Dan.
"""

let colore_che_voglio_2 = Color(red: 0.9098, green: 0.3333, blue: 0)

public struct Pagina5: View {
    public var body: some View {
        
        ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
        
        VStack(alignment: .center, spacing: 10){
            
            Text(storia)
                .font(Font.custom("Avenir Roman", size: 14.0))
                .foregroundColor(Color.white)
                .frame(width: 350.0, height: 100.0)
                //.padding()
            
            
            VStack(alignment: .center) {
                        Spacer()
                        Button(action:{
                            struct Pagina7: View {
                                var body: some View {
                                    
                                    ZStack {
                                                Color.black
                                                    .ignoresSafeArea()
                                                
                                    
                                    VStack(alignment: .center, spacing: 10){
                                        
                                        Text(storia)
                                            .font(Font.custom("Avenir Roman", size: 14.0))
                                            .foregroundColor(Color.white)
                                            .frame(width: 350.0, height: 100.0)
                                            .padding()
                                        
                                    
                                        
                                        scena7
                                                .resizable()
                                                .scaledToFit()
                                                .aspectRatio(contentMode:.fit)
                                                .frame(width: 400.0, height: 300.0)
                                        
                                        
                                        
                                        Text("The End")
                                            .font(.title)
                                            .font(Font.custom("Avenir Roman", size: 14.0))
                                            .foregroundColor(Color.white)
                                            .frame(width: 350.0, height: 100.0)
                                            .padding()
                                        
                                        
                                            }.padding(20)
                                    
                                        
                                        }
                                        
                                    
                                }
                                
                                }
                                


                            PlaygroundPage.current.setLiveView(Pagina7())

                                
                        }){
                            Text("Destroy the Garbage")
                            .bold()
                            .font(Font.custom("Avenir Roman", size: 15.0))
                            .padding(10)
                            .foregroundColor(Color.white)
                            .background(colore_che_voglio)
                            .cornerRadius(25)
                        }
                        Spacer()
                Button(action:{
                    struct Pagina7: View {
                    var body: some View {
                        
                        ZStack {
                                    Color.black
                                        .ignoresSafeArea()
                                    
                        
                        VStack(alignment: .center, spacing: 10){
                            
                            Text(storia_heaven)
                                .font(Font.custom("Avenir Roman", size: 14.0))
                                .foregroundColor(Color.white)
                                .frame(width: 350.0, height: 100.0)
                                .padding()
                            
                        
                            
                            scena7
                                    .resizable()
                                    .scaledToFit()
                                    .aspectRatio(contentMode:.fit)
                                    .frame(width: 400.0, height: 300.0)
                            
                            
                            
                            Text("The End")
                                .font(.title)
                                .font(Font.custom("Avenir Roman", size: 14.0))
                                .foregroundColor(Color.white)
                                .frame(width: 350.0, height: 100.0)
                                .padding()
                            
                            
                                }.padding(20)
                        
                            
                            }
                            
                        
                    }
                    
                    }
                    


                PlaygroundPage.current.setLiveView(Pagina7())

                    }){
                    Text("Find the last plant and restart agricolture")
                    .bold()
                    .font(Font.custom("Avenir Roman", size: 15.0))
                    .padding(10)
                    .foregroundColor(Color.white)
                    .background(colore_che_voglio)
                    .cornerRadius(25)
                }
                Spacer()
                
                Button(action:{
                    struct Pagina6: View {
                        var body: some View {
                            
                            ZStack {
                                        Color.black
                                            .ignoresSafeArea()
                                        
                            
                            VStack(alignment: .center, spacing: 10){
                                
                                Text(storia_hell)
                                    .font(Font.custom("Avenir Roman", size: 14.0))
                                    .foregroundColor(Color.white)
                                    .frame(width: 350.0, height: 100.0)
                                    .padding()
                                
                                                    
                                
                                scena6
                                        .resizable()
                                        .scaledToFit()
                                        .aspectRatio(contentMode:.fit)
                                        .frame(width: 400.0, height: 300.0)
                                
                                
                                Text("The End")
                                    .font(.title)
                                    .font(Font.custom("Avenir Roman", size: 14.0))
                                    .foregroundColor(Color.white)
                                    .frame(width: 350.0, height: 100.0)
                                    .padding()
                                
                                    }.padding(20)
                            
                                
                                }
                                
                            
                        }
                        
                        }
                        


                    PlaygroundPage.current.setLiveView(Pagina6())

                        
                }){
                    Text("Find the last plant and kill it")
                    .bold()
                    .font(Font.custom("Avenir Roman", size: 15.0))
                    .padding(10)
                    .foregroundColor(Color.white)
                    .background(colore_che_voglio)
                    .cornerRadius(25)
                    
                }
                Spacer()
            }.padding(20)
            
            
            scena5
                    .resizable()
                    .scaledToFit()
                    .aspectRatio(contentMode:.fit)
                    .frame(width: 400.0, height: 300.0)
            
                }.padding(20)
        
            
            }
           
        
    }
    
    }
    


PlaygroundPage.current.setLiveView(Pagina5())

    
  


//: [Next](@next)




