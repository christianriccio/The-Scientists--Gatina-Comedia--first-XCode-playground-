import SwiftUI
import PlaygroundSupport
import Foundation
import AVFoundation
//------------------- Audioplayer
//class MusicPlayer {
//static let shared = MusicPlayer()
//var audioPlayer: AVAudioPlayer?
//
//func startBackgroundMusic() {
//if let bundle = Bundle.main.path(forResource: "GatitosCut", ofType: "m4a") {
//    let backgroundMusic = NSURL(fileURLWithPath: bundle)
//    do {
//        audioPlayer = try AVAudioPlayer(contentsOf:backgroundMusic as URL)
//        guard let audioPlayer = audioPlayer else { return }
//        audioPlayer.numberOfLoops = -1
//        audioPlayer.prepareToPlay()
//        audioPlayer.play()
//    } catch {
//        print(error)
//    }
//}
//}
//}
//MusicPlayer.shared.startBackgroundMusic()
//-------------------- Audioplayer


let scena1 = Image(uiImage: UIImage(named: "scena1_pag1.png")!)
let scena2 = Image(uiImage: UIImage(named: "scena2.png")!)
let storia1 = """
        Once upon a time there were two cats and their names were Dan and Trix.
        """

let storia2 = """
Suddenly Dan and Trix are separated by an evil being. Dan is sent to the cat-Heaven, while Trix has to embark on a journey to find her lover.
"""
let colore = Color(red: 0.3882, green: 0, blue : 0.4863)
var flag : Bool = false


    struct Pagina1: View {
        @State private var prima_scena : Bool = true //boolen di appoggio
        @State public var audioPlayer: AVAudioPlayer?

        var body: some View {

            
            ZStack {
                            Color.black
                            .ignoresSafeArea()
            VStack(alignment: .center, spacing: 10){
                
                
                
                Text("GATINA COMEDIA")
                .bold()
                .font(.title)
                .font(Font.custom("Avenir Roman", size: 20.0))
                .foregroundColor(Color.white)
                .padding()
                
                
                    Text(storia1)
                        .font(Font.custom("Avenir Roman", size: 14.0))
                        .foregroundColor(Color.white)
                        .frame(width: 320.0, height: 40.0)
                        .padding()
                    
                    
                    scena1
                            .resizable()
                            .scaledToFit()
                            .aspectRatio(contentMode:.fit)
                            .frame(width: 320.0, height: 320.0)
                    
                
                
                         
                HStack {
                            Spacer()
                            Button(action:{
                                
                                var bombSoundEffect: AVAudioPlayer?
                                let path = Bundle.main.path(forResource: "GatitosCut.m4a", ofType:nil)!
                                let url = URL(fileURLWithPath: path)

                                do {
                                    bombSoundEffect = try AVAudioPlayer(contentsOf: url)
                                    bombSoundEffect?.play()
                                } catch {
                                    // couldn't load file :(
                                }
                          
                                print("button tapped2")
//                                //                                -----------------------
//                                                                        func playAudio() { /// function to play audio
//
//                                                                               /// the URL of the audio file.
//                                                                               /// forResource = name of the file.
//                                                                               /// withExtension = extension, usually "mp3"
//                                                                               if let audioURL = Bundle.main.url(forResource: "OvniCut", withExtension: "m4a") {
//                                                                                       do {
//                                                                                               try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
//                                                                                               self.audioPlayer?.numberOfLoops = 0 /// Number of times to loop the audio
//                                                                                               self.audioPlayer?.play() /// start playing
//
//                                                                                       } catch {
//                                                                                               print("Couldn't play audio. Error: \(error)")
//                                                                                       }
//
//                                                                               } else {
//                                                                                       print("No audio file found")
//                                                                               }
//
//
//
//
//                                                                   }
//                                playAudio()
////                                                                    playAudio()
//                                //                                ------------------------
                                
                                
                                struct Pagina2: View {
                                    @State var audioPlayer: AVAudioPlayer?
                                    
//
                                    var body: some View {
                                        
                                        
                                        ZStack {
                                                    Color.black
                                                        .ignoresSafeArea()
                                                    
                                        
                                        VStack(alignment: .center, spacing: 10){
                                            
                                            Text(storia2)
                                                .font(Font.custom("Avenir Roman", size: 14.0))
                                                .foregroundColor(Color.white)
                                                .frame(width: 320.0, height: 70.0)
                                                .padding()
                                            
                                            
                                            
                                            
                                            
                                            scena2
                                                    .resizable()
                                                    .scaledToFit()
                                                    .aspectRatio(contentMode:.fit)
                                                    .frame(width: 320.0, height: 320.0)
                                            
                                               
                                        
                                            
                                            HStack {
                                                        Spacer()
                                                        Button(action:{}){
                                                            Text(">")
                                                            .bold()
                                                            .font(Font.custom("Avenir Roman", size: 15.0))
                                                            .padding(10)
                                                            .foregroundColor(Color.white)
                                                            .background(Color.green) //si può fare anche verde scuro poichè cosi si richiama la scena o darkgrey
                                                            .cornerRadius(25)
                                                        }
                                                        Spacer()
                                            }
                                            
                                        }.padding(20)
                                            
                                        }
                                  
                                        
                                    }
                                    
                                    
                                    }
//                                self.playAudio()
                 PlaygroundPage.current.setLiveView(Pagina2())
                       
                               
    
                            }){
                                
                                Text(">")
                                .bold()
                                .font(Font.custom("Avenir Roman", size: 15.0))
                                .padding(10)
                                .foregroundColor(Color.white)
                                .background(colore)
                                .cornerRadius(25)
                            }
                            Spacer()
                
                }.frame(width: 100, height: 100) //fine hstack
                
                    
            }// fine zstack
            
        }
                
        }
//        public func playAudio() { /// function to play audio
//
//                       /// the URL of the audio file.
//                       /// forResource = name of the file.
//                       /// withExtension = extension, usually "mp3"
//                       if let audioURL = Bundle.main.url(forResource: "OvniCut", withExtension: "m4a") {
//                               do {
//                                       try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
//                                       self.audioPlayer?.numberOfLoops = 0 /// Number of times to loop the audio
//                                       self.audioPlayer?.play() /// start playing
//
//                               } catch {
//                                       print("Couldn't play audio. Error: \(error)")
//                               }
//
//                       } else {
//                               print("No audio file found")
//                       }
//
//
//
//
//           }

        } // fine view
       
    
    PlaygroundPage.current.setLiveView(Pagina1())
   




    
        
      




