//:[Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

let scena2 = Image(uiImage: UIImage(named: "scena2.png")!)
let storia = """
Suddenly Dan and Trix are separated by an evil being. Dan is sent to the cat-Heaven, while Trix has to embark on a journey to find her lover.
"""

struct Pagina2: View {
    var body: some View {
        
        ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
        
        VStack(alignment: .center, spacing: 10){
            
            Text(storia)
                .font(Font.custom("Avenir Roman", size: 14.0))
                .foregroundColor(Color.white)
                .frame(width: 320.0, height: 70.0)
                .padding()
            
            
            
            
            
            scena2
                    .resizable()
                    .scaledToFit()
                    .aspectRatio(contentMode:.fit)
                    .frame(width: 320.0, height: 320.0)
            
               
        
            
            HStack {
                        Spacer()
                        Button(action:{}){
                            Text(">")
                            .bold()
                            .font(Font.custom("Avenir Roman", size: 15.0))
                            .padding(10)
                            .foregroundColor(Color.white)
                            .background(Color.green) //si può fare anche verde scuro poichè cosi si richiama la scena o darkgrey
                            .cornerRadius(25)
                        }
                        Spacer()
            }
            
        }.padding(20)
        }
           
        
    }
    
    }
    


PlaygroundPage.current.setLiveView(Pagina2())

 


//: [Next](@next)
