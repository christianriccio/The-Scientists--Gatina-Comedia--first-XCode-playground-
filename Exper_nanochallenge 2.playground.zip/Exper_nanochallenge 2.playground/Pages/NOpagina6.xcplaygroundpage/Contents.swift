//:[Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

let scena7 = Image(uiImage: UIImage(named: "scena7.png")!)
let storia = """
In the end Trix, because of all the good choices she made, during her journey, ends up in Heaven. Here is finally reunited with Dan and the live happily ever after together!!!
"""

let colore = Color(red: 0.3882, green: 0, blue : 0.4863)
struct Pagina7: View {
    var body: some View {
        
        ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
        
        VStack(alignment: .center, spacing: 10){
            
            Text(storia)
                .font(Font.custom("Avenir Roman", size: 14.0))
                .foregroundColor(Color.white)
                .frame(width: 350.0, height: 100.0)
                .padding()
            
        
            
            scena7
                    .resizable()
                    .scaledToFit()
                    .aspectRatio(contentMode:.fit)
                    .frame(width: 400.0, height: 300.0)
            
            
            
            Text("The End")
                .font(.title)
                .font(Font.custom("Avenir Roman", size: 14.0))
                .foregroundColor(Color.white)
                .frame(width: 350.0, height: 100.0)
                .padding()
            
            
                }.padding(20)
        
            
            }
            
        
    }
    
    }
    


PlaygroundPage.current.setLiveView(Pagina7())

    
  


//: [Next](@next)






