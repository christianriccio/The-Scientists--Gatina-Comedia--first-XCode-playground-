//:[Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

let scena3 = Image(uiImage: UIImage(named: "scena3.png")!)
let storia = """
After the evil being separates the two lovers, Trix is sent to the past and has to face a sorcerer. Upon arriving in the past she is transformed into a cat-dragon. She can now choose between 3 possible actions...
"""


let colore_bottoni = Color(red: 0.4, green: 0.0431, blue: 0)

struct Pagina3: View {
    var body: some View {
        
        ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
        
        VStack(alignment: .center, spacing: 10){
            
            Text(storia)
                .font(Font.custom("Avenir Roman", size: 14.0))
                .foregroundColor(Color.white)
                .frame(width: 390.0, height: 80.0)
                .padding()
            
            
            HStack {
                        Spacer()
                        Button(action:{}){
                            Text("Kill the Sorcerer")
                            .bold()
                            .font(Font.custom("Avenir Roman", size: 15.0))
                            .padding(10)
                            .foregroundColor(Color.white)
                            .background(colore_bottoni)
                            .cornerRadius(25)
                        }
                        Spacer()
                Button(action:{}){
                    Text("Play with the sorcerer")
                    .bold()
                    .font(Font.custom("Avenir Roman", size: 15.0))
                    .padding(10)
                    .foregroundColor(Color.white)
                    .background(colore_bottoni)
                    .cornerRadius(25)
                }
                Spacer()
                
                Button(action:{}){
                    Text("Fly away")
                    .bold()
                    .font(Font.custom("Avenir Roman", size: 15.0))
                    .padding(10)
                    .foregroundColor(Color.white)
                    .background(colore_bottoni)
                    .cornerRadius(25)
                    
                }
                Spacer()
            }.padding(20)
            
            
            scena3
                    .resizable()
                    .scaledToFit()
                    .aspectRatio(contentMode:.fit)
                    .frame(width: 390.0, height: 320.0)
            
                }.padding(20)
        
            
            }
            
        
    }
    
    }
    


PlaygroundPage.current.setLiveView(Pagina3())

    
  


//: [Next](@next)


