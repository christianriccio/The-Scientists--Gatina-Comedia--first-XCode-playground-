//:[Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

let scena4 = Image(uiImage: UIImage(named: "scena4.png")!)
let storia = """
Following her interaction with the Sorcerer, Trix is able to go to the Present, where she meets a bat named Bruce. At this point she is, again, presented with 3 possible courses of action
"""

let scena6 = Image(uiImage: UIImage(named: "scena6.png")!)
let storiaHell_bruce = """
Because Trix decides to kill Bruce she contracts the Corona Virus and the complications kill her. She ends up in Hell where she will spend all her time alone without Dan...
"""


struct Pagina4: View {
    var body: some View {
        
        ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
        
        VStack(alignment: .center, spacing: 10){
            
            Text(storia)
                .font(Font.custom("Avenir Roman", size: 14.0))
                .foregroundColor(Color.white)
                .frame(width: 390.0, height: 80.0)
                .padding()
            
            
            HStack {
                        Spacer()
                        Button(action:{struct Pagina6: View {
                            var body: some View {
                               
                               ZStack {
                                           Color.black
                                               .ignoresSafeArea()
                                           
                               
                               VStack(alignment: .center, spacing: 10){
                                   
                                   Text(storiaHell_bruce)
                                       .font(Font.custom("Avenir Roman", size: 14.0))
                                       .foregroundColor(Color.white)
                                       .frame(width: 350.0, height: 100.0)
                                       .padding()
                                   
                                                       
                                   
                                   scena6
                                           .resizable()
                                           .scaledToFit()
                                           .aspectRatio(contentMode:.fit)
                                           .frame(width: 400.0, height: 300.0)
                                   
                                   
                                   Text("The End")
                                       .font(.title)
                                       .font(Font.custom("Avenir Roman", size: 14.0))
                                       .foregroundColor(Color.white)
                                       .frame(width: 350.0, height: 100.0)
                                       .padding()
                                   
                                       }.padding(20)
                               
                                   
                                   }
                                   
                               
                           }
                           
                           }
                           


                       PlaygroundPage.current.setLiveView(Pagina6())
}){
                            Text("Kill Bruce")
                            .bold()
                            .font(Font.custom("Avenir Roman", size: 15.0))
                            .padding(10)
                            .foregroundColor(Color.white)
                            .background(Color.gray)
                            .cornerRadius(25)
                        }
                        Spacer()
                Button(action:{}){
                    Text("Play with Bruce")
                    .bold()
                    .font(Font.custom("Avenir Roman", size: 15.0))
                    .padding(10)
                    .foregroundColor(Color.white)
                    .background(Color.gray)
                    .cornerRadius(25)
                }
                Spacer()
                
                Button(action:{}){
                    Text("Give Bruce her number")
                    .bold()
                    .font(Font.custom("Avenir Roman", size: 15.0))
                    .padding(10)
                    .foregroundColor(Color.white)
                    .background(Color.gray)
                    .cornerRadius(25)
                    
                }
                Spacer()
            }.padding(20)
            
            
            scena4
                    .resizable()
                    .scaledToFit()
                    .aspectRatio(contentMode:.fit)
                    .frame(width: 400.0, height: 320.0)
            
                }.padding(20)
        
            
            }
            
        
    }
    
    }
    


PlaygroundPage.current.setLiveView(Pagina4())

    
  


//: [Next](@next)



