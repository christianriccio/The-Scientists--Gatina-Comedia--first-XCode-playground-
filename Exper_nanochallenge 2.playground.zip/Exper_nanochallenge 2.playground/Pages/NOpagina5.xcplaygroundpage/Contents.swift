//:[Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

let scena6 = Image(uiImage: UIImage(named: "scena6.png")!)
let storia = """
In the end, because of the bad choices she made during her journey, Trix ends up in Hell, forever alone without her lover Dan.
"""

let colore_che_voglio = Color(red: 0.9098, green: 0.3333, blue: 0)

struct Pagina6: View {
     var body: some View {
        
        ZStack {
                    Color.black
                        .ignoresSafeArea()
                    
        
        VStack(alignment: .center, spacing: 10){
            
            Text(storia)
                .font(Font.custom("Avenir Roman", size: 14.0))
                .foregroundColor(Color.white)
                .frame(width: 350.0, height: 100.0)
                .padding()
            
                                
            
            scena6
                    .resizable()
                    .scaledToFit()
                    .aspectRatio(contentMode:.fit)
                    .frame(width: 400.0, height: 300.0)
            
            
            Text("The End")
                .font(.title)
                .font(Font.custom("Avenir Roman", size: 14.0))
                .foregroundColor(Color.white)
                .frame(width: 350.0, height: 100.0)
                .padding()
            
                }.padding(20)
        
            
            }
            
        
    }
    
    }
    


PlaygroundPage.current.setLiveView(Pagina6())

    
  


//: [Next](@next)





